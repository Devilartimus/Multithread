#ifndef SOCKET_CLASS_H
#define SOCKET_CLASS_H

#include <iostream>
#include <cstring>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

class Socket
{
public:
    Socket() : socket_fd(-1) {}

    bool create()
    {
        socket_fd = socket(AF_INET, SOCK_STREAM, 0);
        return socket_fd != -1;
    }

    bool bind(unsigned short port)
    {
        struct sockaddr_in serverAddr;
        std::memset(&serverAddr, 0, sizeof(serverAddr));
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_addr.s_addr = INADDR_ANY;
        serverAddr.sin_port = htons(port);
        return bind(socket_fd, reinterpret_cast<struct sockaddr*>(&serverAddr), sizeof(serverAddr)) != -1;
    }

    bool listen(int backlog)
    {
        return listen(socket_fd, backlog) != -1;
    }

    int accept(struct sockaddr* clientAddr, socklen_t* clientAddrSize)
    {
        return accept(socket_fd, clientAddr, clientAddrSize);
    }

    bool send(const char* data, size_t size)
    {
        return ::send(client_socket_fd, data, size, 0) != -1;
    }

    bool close() {
        if (socket_fd != -1)
        {
            close(socket_fd);
            socket_fd = -1;
            return true;
        }
        return false;
    }

    bool setClientSocket(int clientSocket)
    {
        client_socket_fd = clientSocket;
        return client_socket_fd != -1;
    }

private:
    int socket_fd;
    int client_socket_fd;
};

#endif
