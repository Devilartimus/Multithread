#include <iostream>
#include <thread>
#include "Reader_class.h"
#include "Writer_class.h"
#include "Queue_class.h"

int main() {
    bufferQueue queue;
    std::mutex queueMutex;
    std::condition_variable cv;

    Reader reader(queue, queueMutex, cv);
    Writer writer(queue, reader, queueMutex, cv);

    std::thread input(reader);
    std::thread output(writer);

    input.join();
    output.join();

    return 0;
}
