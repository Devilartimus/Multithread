#ifndef WRITER_CLASS_H
#define WRITER_CLASS_H

#include <thread>
#include <iostream>
#include <cctype>
#include "Socket_class.h"
#include "Queue_class.h"
#include "Reader_class.h"

class Writer
{
public:
    Writer(bufferQueue& queue, Reader& reader, std::mutex& queueMutex, std::condition_variable& cv)
        : bufferQueue(queue), reader(reader), queueMutex(queueMutex), cv(cv) {}

    void operator()()
    {
        while (true)
        {
            std::string data = bufferQueue.pop();

            std::cout << "\n\nReceived string: " << data << std::endl;

            int sum = 0;
            for (char a : data)
            {
                if (std::isdigit(a))
                    sum += a - '0';
            }

            std::cout << "Sum of digits: " << sum << std::endl;

            while (true)
            {
                Socket serverSocket;
                if (!serverSocket.create())
                {
                    std::cerr << "Error: Unable to create socket\n";
                    break;
                }

                if (!serverSocket.bind(12345))
                {
                    std::cerr << "Error: Unable to bind socket\n";
                    serverSocket.close();
                    continue;
                }

                if (!serverSocket.listen(5))
                {
                    std::cerr << "Error: Unable to listen on socket\n";
                    serverSocket.close();
                    continue;
                }

                struct sockaddr_in clientAddr;
                socklen_t clientAddrSize = sizeof(clientAddr);
                int clientSocket = serverSocket.accept(reinterpret_cast<struct sockaddr*>(&clientAddr), &clientAddrSize);
                if (clientSocket < 0)
                {
                    std::cerr << "Error: Unable to accept connection\n";
                    serverSocket.close();
                    continue;
                }

                if (!serverSocket.setClientSocket(clientSocket))
                {
                    std::cerr << "Error: Unable to set client socket\n";
                    close(clientSocket);
                    serverSocket.close();
                    continue;
                }

                if (!serverSocket.send(data.c_str(), data.size()))
                {
                    std::cerr << "Error: Unable to send data\n";
                }

                close(clientSocket);
                serverSocket.close();
            }
        }
    }

private:
    bufferQueue& bufferQueue;
    Reader& reader;
    std::mutex& queueMutex;
    std::condition_variable& cv;
};

#endif
