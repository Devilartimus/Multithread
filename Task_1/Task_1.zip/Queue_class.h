#ifndef QUEUE_CLASS_H
#define QUEUE_CLASS_H

#include <queue>
#include <string>
#include <mutex>
#include <condition_variable>

class bufferQueue
{
private:
    std::queue<std::string> bufferQueue;
    mutable std::mutex queueMutex;
    std::condition_variable cv;

public:
    void push(const std::string& str)
    {
        std::lock_guard<std::mutex> lock(queueMutex);
        bufferQueue.push(str);
        cv.notify_all();
    }

    std::string pop()
    {
        std::unique_lock<std::mutex> lock(queueMutex);
        cv.wait(lock, [this] { return !bufferQueue.empty(); });
        std::string data = bufferQueue.front();
        bufferQueue.pop();
        return data;
    }

    bool empty() const
    {
        std::lock_guard<std::mutex> lock(queueMutex);
        return bufferQueue.empty();
    }
};

#endif
