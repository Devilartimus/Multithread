    #ifndef READER_CLASS_H
    #define READER_CLASS_H

    #include <iostream>
    #include <algorithm>
    #include "Queue_class.h"

    class Reader
    {
    public:
        Reader(bufferQueue& bufferQueue, std::mutex& queueMutex, std::condition_variable& cv)
            : bufferQueue(bufferQueue), queueMutex(queueMutex), cv(cv) {}

        void operator()()
        {
            while (true)
            {
                std::string input;
                std::cout << "Enter a string of numbers (max. 64 characters) \nor enter 'exit' if you want to close the program: ";
                std::getline(std::cin, input);

                if (std::cin.eof() || input == "exit")
                {
                    std::cout << "Program closed." << std::endl;
                    break;
                }

                if (!isValid(input))
                {
                    std::cerr << "Input error! Try again." << std::endl;
                    continue;
                }

                std::sort(input.begin(), input.end(), std::greater<char>());

                for (char a : input)
                {
                    if ((a - '0') % 2 == 0)
                        bufferQueue.push("КВ");
                    else
                        bufferQueue.push(std::string(1, a));
                }

                cv.notify_all();
            }
        }

    private:
        bool isValid(const std::string& str)
        {
            return str.size() <= 64 && str.find_first_not_of("0123456789") == std::string::npos;
        }

        bufferQueue& bufferQueue;
        std::mutex& queueMutex;
        std::condition_variable& cv;
    };

    #endif

